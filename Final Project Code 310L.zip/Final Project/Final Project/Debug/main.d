main.d main.o: .././main.c \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\io.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\sfr_defs.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\inttypes.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\features.h \
 c:\program\ files\microchip\xc8\v2.36\avr\lib\gcc\avr\5.4.0\include\stdint.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\stdint.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\bits\alltypes.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\bits\stdint.h \
 C:/Program\ Files\ (x86)/Atmel/Studio/7.0/Packs/atmel/ATmega_DFP/1.7.374/xc8/avr/include/avr/iom328p.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\portpins.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\common.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\fuse.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\lock.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\util\delay.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\util\delay_basic.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\math.h \
 ../csrc/u8g2.h ../csrc/u8x8.h \
 c:\program\ files\microchip\xc8\v2.36\avr\lib\gcc\avr\5.4.0\include\stdarg.h \
 c:\program\ files\microchip\xc8\v2.36\avr\lib\gcc\avr\5.4.0\include\stddef.h \
 c:\program\ files\microchip\xc8\v2.36\avr\lib\gcc\avr\5.4.0\include-fixed\limits.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\pgmspace.h \
 ../lib/u8x8_avr.h .././as608.h .././lock_servo.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\eeprom.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\string.h \
 c:\program\ files\microchip\xc8\v2.36\avr\avr\include\stdlib.h

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\io.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\sfr_defs.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\inttypes.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\features.h:

c:\program\ files\microchip\xc8\v2.36\avr\lib\gcc\avr\5.4.0\include\stdint.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\stdint.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\bits\alltypes.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\bits\stdint.h:

C:/Program\ Files\ (x86)/Atmel/Studio/7.0/Packs/atmel/ATmega_DFP/1.7.374/xc8/avr/include/avr/iom328p.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\portpins.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\common.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\fuse.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\lock.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\util\delay.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\util\delay_basic.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\math.h:

../csrc/u8g2.h:

../csrc/u8x8.h:

c:\program\ files\microchip\xc8\v2.36\avr\lib\gcc\avr\5.4.0\include\stdarg.h:

c:\program\ files\microchip\xc8\v2.36\avr\lib\gcc\avr\5.4.0\include\stddef.h:

c:\program\ files\microchip\xc8\v2.36\avr\lib\gcc\avr\5.4.0\include-fixed\limits.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\pgmspace.h:

../lib/u8x8_avr.h:

.././as608.h:

.././lock_servo.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\avr\eeprom.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\string.h:

c:\program\ files\microchip\xc8\v2.36\avr\avr\include\stdlib.h:
